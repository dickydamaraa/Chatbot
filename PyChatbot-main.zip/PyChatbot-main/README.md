# Note
Now the bot needs an api key to work 

get ur api key from [here](https://api-info.pgamerx.com/register)

# Installation 
[Video on how to set it up](https://youtu.be/owgf1KmZaPI)


OR Follow the steps bellow



#### clone the repo  
$ git clone https://github.com/L-eviH-AckermanYT/PyChatbot

#### change the working directory to PyChatbot  
$ cd Python-Chatbot

#### download the requirements  
$ pip3 install -r requirements.txt

#### run the program
$ python3 main.py
